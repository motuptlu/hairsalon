// MOTEA Hair Salon - Main JavaScript
document.addEventListener('DOMContentLoaded', function() {
    
    // Initialize all animations and interactions
    initAnimations();
    initNavigation();
    initContactForm();
    initScrollEffects();
    initCursorFollower();
    
    // Initialize Google Maps if on contact page
    if (document.getElementById('map')) {
        initMap();
    }
});

// GSAP Animations
function initAnimations() {
    // Logo line draw animation
    const logoPaths = document.querySelectorAll('.logo-line-draw');
    logoPaths.forEach(path => {
        const length = path.getTotalLength();
        path.style.strokeDasharray = length;
        path.style.strokeDashoffset = length;
        
        // Animate logo drawing
        gsap.to(path, {
            strokeDashoffset: 0,
            duration: 2,
            ease: "power2.out",
            delay: 0.5
        });
    });
    
    // Hero title animation
    const heroTitle = document.getElementById('heroTitle');
    if (heroTitle) {
        const textSpans = heroTitle.querySelectorAll('span');
        gsap.fromTo(textSpans, 
            {y: 100, opacity: 0},
            {y: 0, opacity: 1, duration: 1, stagger: 0.2, delay: 1}
        );
    }
    
    // Hero subtitle animation
    const heroSubtitle = document.getElementById('heroSubtitle');
    if (heroSubtitle) {
        gsap.to(heroSubtitle, {
            opacity: 1,
            duration: 1,
            delay: 1.5
        });
    }
    
    // Hero CTA animation
    const heroCTA = document.getElementById('heroCTA');
    if (heroCTA) {
        gsap.to(heroCTA, {
            opacity: 1,
            duration: 1,
            delay: 2
        });
    }
    
    // Navigation logo hover animation
    const navLogo = document.getElementById('navLogo');
    if (navLogo) {
        navLogo.addEventListener('mouseenter', () => {
            gsap.to(navLogo, {scale: 1.1, duration: 0.3, ease: "power2.out"});
        });
        
        navLogo.addEventListener('mouseleave', () => {
            gsap.to(navLogo, {scale: 1, duration: 0.3, ease: "power2.out"});
        });
    }
}

// Navigation functionality
function initNavigation() {
    // Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mobileMenu = document.getElementById('mobileMenu');
    
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
            
            // Animate menu appearance
            if (!mobileMenu.classList.contains('hidden')) {
                gsap.fromTo(mobileMenu, 
                    {opacity: 0, y: -20},
                    {opacity: 1, y: 0, duration: 0.3}
                );
            }
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                gsap.to(window, {
                    scrollTo: target,
                    duration: 1,
                    ease: "power2.out"
                });
            }
        });
    });
    
    // Navbar scroll effect
    const navbar = document.querySelector('nav');
    let lastScrollTop = 0;
    
    window.addEventListener('scroll', () => {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // Add background blur effect on scroll
        if (scrollTop > 50) {
            navbar.classList.add('backdrop-blur-md');
            navbar.classList.remove('bg-motea-black/90');
            navbar.classList.add('bg-motea-black/95');
        } else {
            navbar.classList.remove('backdrop-blur-md');
            navbar.classList.add('bg-motea-black/90');
            navbar.classList.remove('bg-motea-black/95');
        }
        
        lastScrollTop = scrollTop;
    });
}

// Contact form functionality
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(contactForm);
            const data = {
                name: formData.get('name'),
                email: formData.get('email'),
                phone: formData.get('phone'),
                service: formData.get('service'),
                message: formData.get('message')
            };
            
            // Validate form
            if (!data.name || !data.email || !data.message) {
                showNotification('Please fill in all required fields.', 'error');
                return;
            }
            
            // Show loading state
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Sending...';
            submitBtn.disabled = true;
            
            // Simulate form submission (in real app, send to server)
            setTimeout(() => {
                // Reset form
                contactForm.reset();
                
                // Show success message
                const successDiv = document.getElementById('formSuccess');
                if (successDiv) {
                    successDiv.classList.remove('hidden');
                    gsap.fromTo(successDiv,
                        {opacity: 0, scale: 0.8},
                        {opacity: 1, scale: 1, duration: 0.5}
                    );
                }
                
                // Reset button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                
                // Hide success message after 5 seconds
                setTimeout(() => {
                    successDiv.classList.add('hidden');
                }, 5000);
                
                // Email integration (in real app)
                if (data.email) {
                    const subject = encodeURIComponent('MOTEA Salon Inquiry');
                    const body = encodeURIComponent(`
                        Name: ${data.name}
                        Email: ${data.email}
                        Phone: ${data.phone}
                        Service Interest: ${data.service}
                        
                        Message: ${data.message}
                    `);
                    window.open(`mailto:salonmotel@gmail.com?subject=${subject}&body=${body}`);
                }
                
            }, 2000);
        });
    }
}

// Scroll animations
function initScrollEffects() {
    // ScrollTrigger for fade-up animations
    gsap.register(ScrollTrigger);
    
    // Fade up elements
    const fadeUpElements = document.querySelectorAll('.fade-in-up, .fade-up, .slide-in-left, .slide-in-right');
    
    fadeUpElements.forEach(element => {
        gsap.fromTo(element,
            {y: 50, opacity: 0},
            {
                y: 0,
                opacity: 1,
                duration: 0.8,
                ease: "power2.out",
                scrollTrigger: {
                    trigger: element,
                    start: "top 80%",
                    end: "bottom 20%",
                    toggleActions: "play none none reverse"
                }
            }
        );
    });
    
    // Text reveal animations for service cards
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach((card, index) => {
        gsap.fromTo(card,
            {y: 100, opacity: 0},
            {
                y: 0,
                opacity: 1,
                duration: 0.8,
                delay: index * 0.1,
                ease: "power2.out",
                scrollTrigger: {
                    trigger: card,
                    start: "top 85%",
                    toggleActions: "play none none reverse"
                }
            }
        );
    });
    
    // Parallax effects for background elements
    const parallaxElements = document.querySelectorAll('.parallax-bg');
    parallaxElements.forEach(element => {
        gsap.to(element, {
            yPercent: -50,
            ease: "none",
            scrollTrigger: {
                trigger: element,
                start: "top bottom",
                end: "bottom top",
                scrub: true
            }
        });
    });
}

// Cursor follower effect
function initCursorFollower() {
    const cursor = document.querySelector('.cursor-follower');
    
    if (!cursor) return;
    
    let mouseX = 0;
    let mouseY = 0;
    let cursorX = 0;
    let cursorY = 0;
    
    // Update mouse position
    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });
    
    // Smooth cursor animation
    function animateCursor() {
        cursorX += (mouseX - cursorX) * 0.1;
        cursorY += (mouseY - cursorY) * 0.1;
        
        cursor.style.left = cursorX - 10 + 'px';
        cursor.style.top = cursorY - 10 + 'px';
        
        requestAnimationFrame(animateCursor);
    }
    
    animateCursor();
    
    // Hover effects for interactive elements
    const hoverElements = document.querySelectorAll('a, button, .service-card, .masonry-item');
    hoverElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            cursor.style.transform = 'scale(2)';
            cursor.style.background = 'radial-gradient(circle, rgba(192, 192, 192, 0.6) 0%, transparent 70%)';
        });
        
        element.addEventListener('mouseleave', () => {
            cursor.style.transform = 'scale(1)';
            cursor.style.background = 'radial-gradient(circle, rgba(192, 192, 192, 0.8) 0%, transparent 70%)';
        });
    });
}

// Google Maps initialization
function initMap() {
    // MOTEA Hair Salon coordinates (Strovolos, Nicosia, Cyprus)
    const moteaLocation = { lat: 35.1856, lng: 33.3823 };
    
    // Create map
    const map = new google.maps.Map(document.getElementById('map'), {
        zoom: 15,
        center: moteaLocation,
        mapTypeId: 'roadmap',
        styles: [
            {
                "featureType": "all",
                "elementType": "geometry",
                "stylers": [{"color": "#000000"}]
            },
            {
                "featureType": "all",
                "elementType": "labels.text.fill",
                "stylers": [{"color": "#C0C0C0"}]
            },
            {
                "featureType": "all",
                "elementType": "labels.text.stroke",
                "stylers": [{"color": "#000000"}]
            },
            {
                "featureType": "road",
                "elementType": "geometry",
                "stylers": [{"color": "#1a1a1a"}]
            },
            {
                "featureType": "water",
                "elementType": "geometry",
                "stylers": [{"color": "#333333"}]
            }
        ]
    });
    
    // Custom marker icon
    const markerIcon = {
        url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                <circle cx="20" cy="20" r="18" fill="#C0C0C0" stroke="#FFFFFF" stroke-width="2"/>
                <circle cx="20" cy="20" r="8" fill="#000000"/>
                <text x="20" y="35" text-anchor="middle" fill="#C0C0C0" font-family="Arial" font-size="10" font-weight="bold">MOTEA</text>
            </svg>
        `),
        scaledSize: new google.maps.Size(40, 40),
        anchor: new google.maps.Point(20, 35)
    };
    
    // Add marker
    const marker = new google.maps.Marker({
        position: moteaLocation,
        map: map,
        icon: markerIcon,
        title: 'MOTEA Hair Salon',
        animation: google.maps.Animation.BOUNCE
    });
    
    // Info window
    const infoWindow = new google.maps.InfoWindow({
        content: `
            <div style="color: #000; font-family: 'Poppins', sans-serif; padding: 10px;">
                <h3 style="margin: 0 0 10px 0; color: #C0C0C0; font-family: 'Playfair Display', serif;">MOTEA Hair Salon</h3>
                <p style="margin: 5px 0; color: #666;">A creative space for hair, beauty & art</p>
                <p style="margin: 5px 0; color: #666;">📍 Strovolos, Nicosia, Cyprus</p>
                <p style="margin: 5px 0; color: #666;">📞 +357 96 250400</p>
                <p style="margin: 5px 0; color: #666;">✉️ salonmotel@gmail.com</p>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #999;">Established 1937</p>
            </div>
        `
    });
    
    // Show info window on marker click
    marker.addListener('click', () => {
        infoWindow.open(map, marker);
    });
    
    // Close animation after 3 seconds
    setTimeout(() => {
        marker.setAnimation(null);
    }, 3000);
    
    // Add click handler to open in Google Maps
    map.addListener('click', () => {
        const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${moteaLocation.lat},${moteaLocation.lng}`;
        window.open(googleMapsUrl, '_blank');
    });
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 px-6 py-4 rounded-lg text-white font-semibold transform translate-x-full transition-transform duration-300`;
    
    switch(type) {
        case 'success':
            notification.classList.add('bg-green-500');
            break;
        case 'error':
            notification.classList.add('bg-red-500');
            break;
        default:
            notification.classList.add('bg-motea-silver', 'text-black');
    }
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 4000);
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// Performance optimizations
window.addEventListener('load', () => {
    // Lazy load images
    const images = document.querySelectorAll('img[src]');
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
});

// Smooth scroll to top functionality
function scrollToTop() {
    gsap.to(window, {
        scrollTo: 0,
        duration: 1,
        ease: "power2.out"
    });
}

// Add scroll to top button
const scrollTopBtn = document.createElement('button');
scrollTopBtn.innerHTML = '↑';
scrollTopBtn.className = 'fixed bottom-8 right-8 w-12 h-12 bg-motea-silver text-black rounded-full font-bold text-xl opacity-0 transition-opacity duration-300 z-40 hover:bg-white';
scrollTopBtn.onclick = scrollToTop;
document.body.appendChild(scrollTopBtn);

// Show/hide scroll to top button
window.addEventListener('scroll', throttle(() => {
    if (window.pageYOffset > 500) {
        scrollTopBtn.style.opacity = '1';
    } else {
        scrollTopBtn.style.opacity = '0';
    }
}, 250));

// Initialize GSAP ScrollToPlugin
gsap.registerPlugin(ScrollTrigger);

// Global error handling
window.addEventListener('error', (e) => {
    console.error('JavaScript error:', e.error);
});

// Initialize everything when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('MOTEA Hair Salon website loaded successfully');
});
