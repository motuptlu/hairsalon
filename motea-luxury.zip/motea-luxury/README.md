# MOTEA Hair Salon - Luxury Website

A premium, cinematic hair salon website featuring sophisticated animations, silver luxury theme, and comprehensive business integration.

## 🌟 Features

### Design & Aesthetics
- **Luxury Silver Theme**: Deep black, silver, and white color scheme
- **Cinematic Animations**: GSAP-powered smooth animations and transitions
- **Responsive Design**: Optimized for all devices and screen sizes
- **Premium Typography**: Playfair Display for headings, Poppins for body text

### Logo Integration
- **MOTEA Logo**: Custom animated logo with line-draw reveal effects
- **Logo Animations**: Architectural build-up effects, debossed transitions
- **Favicon**: Browser tab icon from MOTEA logo
- **Watermark Effects**: Large transparent logos as background elements

### Pages & Content
1. **Home Page** (`index.html`)
   - Animated hero section with MOTEA logo reveal
   - Tagline: "A Creative Space for Hair, Beauty & Art"
   - Service previews and heritage showcase

2. **About Page** (`about.html`)
   - Heritage story since 1937
   - Master artisans team showcase
   - Company values and timeline
   - Parallax background effects

3. **Services Page** (`services.html`)
   - Precision Cuts, Color Artistry, Bridal Services
   - Luxury Treatments and Men's Services
   - Animated pricing cards with hover effects
   - Silver dividers between sections

4. **Gallery Page** (`gallery.html`)
   - Masonry layout for portfolio showcase
   - Horizontal scroll gallery
   - Creative space rental information
   - Client testimonials
   - Large watermark logo background

5. **Contact Page** (`contact.html`)
   - Google Maps integration with custom styling
   - Animated contact form with validation
   - Business hours and location details
   - Social media integration

### Technical Features
- **GSAP Animations**: Professional-grade animations and transitions
- **Google Maps Integration**: Interactive map with custom silver pin styling
- **SEO Optimization**: Local Cyprus targeting, structured data
- **Form Handling**: Contact form with email integration
- **Mobile Navigation**: Responsive hamburger menu
- **Scroll Effects**: Parallax backgrounds and fade-in animations

### Animations & Interactions
- **Logo Animations**: Line-draw, scale, and glow effects
- **Text Reveals**: Slide-up animations for content
- **Hover Effects**: Silver glow and transform effects
- **Cursor Follower**: Interactive cursor tracking
- **Scroll Triggers**: Element animations on scroll
- **Form Feedback**: Loading states and success notifications

## 🎨 Brand Identity

- **Business**: MOTEA Hair Salon (Established 1937)
- **Email**: salonmotel@gmail.com
- **Phone**: +357 96 250400
- **Location**: Strovolos, Nicosia, Cyprus
- **Social Media**: Instagram & Facebook integration

## 🛠️ Technologies Used

- **HTML5**: Semantic markup and accessibility
- **CSS3**: Advanced styling with custom animations
- **JavaScript**: Interactive functionality and animations
- **GSAP**: Professional animation library
- **Tailwind CSS**: Utility-first CSS framework
- **Google Maps API**: Interactive mapping functionality
- **Responsive Design**: Mobile-first approach

## 📱 Pages Overview

### Home Page
- Hero section with animated MOTEA logo
- Animated word effects for luxury adjectives
- Service preview cards
- Heritage statistics showcase
- Call-to-action for booking

### About Page
- Company history since 1937
- Team member showcase with hover effects
- Values section with icons
- Interactive timeline
- Parallax background elements

### Services Page
- Detailed service offerings with pricing
- Category-based service organization
- Hover effects on service cards
- Call-to-action for booking consultations
- Silver themed dividers

### Gallery Page
- Portfolio showcase with masonry layout
- Behind-the-scenes horizontal scroll
- Creative space rental information
- Client testimonials
- Large watermark logo background

### Contact Page
- Interactive Google Maps integration
- Professional contact form
- Business information display
- Social media links
- Quick action buttons

## 🎯 SEO Features

- **Local SEO**: Cyprus location optimization
- **Structured Data**: JSON-LD for local business
- **Meta Tags**: Comprehensive SEO meta tags
- **Semantic HTML**: Proper heading hierarchy
- **Performance**: Optimized images and animations

## 📊 Google Maps Integration

- **Location**: Strovolos, Nicosia, Cyprus
- **Custom Styling**: Dark theme matching website
- **Custom Marker**: Silver-themed MOTEA logo marker
- **Info Window**: Business details popup
- **Interactive**: Click to open in Google Maps

## 🚀 Deployment

The website is ready for deployment and includes:
- All assets properly organized
- Optimized file structure
- SEO-ready meta tags
- Favicon implementation
- Responsive design validation

## 📝 File Structure

```
motea-luxury/
├── index.html              # Home page
├── about.html              # About page
├── services.html           # Services page
├── gallery.html            # Gallery page
├── contact.html            # Contact page
├── js/
│   └── main.js            # Main JavaScript file
├── images/
│   ├── motea-logo.png     # Main logo
│   ├── favicon.ico        # Browser favicon
│   └── favicon.png        # Favicon source
└── README.md              # Documentation
```

## 🎨 Animation Details

### Logo Animations
- **Line Draw**: SVG path animation with stroke-dasharray
- **Scale Effects**: Hover transforms with GSAP
- **Glow Effects**: Box-shadow with animation timing
- **Build-up**: Staggered child element reveals

### Text Animations
- **Slide Up**: Transform translateY animations
- **Fade In**: Opacity transitions
- **Stagger Effects**: Sequential element reveals
- **Scroll Triggers**: Element visibility animations

### Interactive Elements
- **Service Cards**: Hover transform and glow effects
- **Button Animations**: Background and text transitions
- **Form Feedback**: Loading states and success messages
- **Navigation**: Smooth scroll and backdrop blur

## 🌟 Premium Features

- **Cinematic Experience**: Movie-like scrolling and animations
- **Luxury Aesthetics**: Silver theme with elegant typography
- **Professional Polish**: Every detail crafted for luxury feel
- **Brand Consistency**: MOTEA logo integration throughout
- **Performance Optimized**: Smooth 60fps animations
- **Accessibility**: Keyboard navigation and screen reader support

## 📞 Business Integration

- **Contact Form**: Professional inquiry handling
- **Google Maps**: Direct location and directions
- **Phone Integration**: Click-to-call functionality
- **Email Integration**: Direct email composition
- **Social Media**: Direct links to Instagram and Facebook

This website represents the pinnacle of luxury hair salon web design, combining artistic beauty with technical excellence to create an unforgettable digital experience for MOTEA Hair Salon's clients.
